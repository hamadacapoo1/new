package com.profitcalc.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Rect;
import android.view.Gravity;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.LinearLayout;
import android.widget.TextView;

// شريط تنقل ثابت تحت بين صفحات التطبيق
public class BottomNav {

    public static final int HOME = 0;
    public static final int LOG = 1;
    public static final int SITES = 2;
    public static final int SUM = 3;

    private static int dp(Activity a, int v) {
        return (int) (v * a.getResources().getDisplayMetrics().density + 0.5f);
    }

    public static View wrap(final Activity a, View content, int current) {
        final LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setBackgroundColor(Color.parseColor("#000000"));
        col.addView(content, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        final LinearLayout bar = new LinearLayout(a);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.setBackgroundColor(Color.parseColor("#111111"));

        View line = new View(a);
        line.setBackgroundColor(Color.parseColor("#2A2A2A"));
        bar.addView(line, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(a, 1)));

        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        row.addView(tab(a, "🏠", "الرئيسية", HOME, current),
            new LinearLayout.LayoutParams(0, dp(a, 56), 1f));
        row.addView(tab(a, "📒", "سجل الأرباح", LOG, current),
            new LinearLayout.LayoutParams(0, dp(a, 56), 1f));
        row.addView(tab(a, "🌐", "مواقعي", SITES, current),
            new LinearLayout.LayoutParams(0, dp(a, 56), 1f));
        row.addView(tab(a, "➕", "الجمع", SUM, current),
            new LinearLayout.LayoutParams(0, dp(a, 56), 1f));
        bar.addView(row);

        col.addView(bar, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // لما الكيبورد يفتح الشريط بيستخبى مؤقتًا عشان ما ياخدش مساحة
        col.getViewTreeObserver().addOnGlobalLayoutListener(
            new ViewTreeObserver.OnGlobalLayoutListener() {
                public void onGlobalLayout() {
                    Rect r = new Rect();
                    col.getWindowVisibleDisplayFrame(r);
                    int full = col.getRootView().getHeight();
                    boolean keyboard = full - r.bottom > dp(a, 120);
                    int want = keyboard ? View.GONE : View.VISIBLE;
                    if (bar.getVisibility() != want) bar.setVisibility(want);
                }
            });
        return col;
    }

    private static View tab(final Activity a, String icon, String label,
                            final int target, final int current) {
        LinearLayout t = new LinearLayout(a);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER);
        boolean active = target == current;
        int color = Color.parseColor(active ? "#34D399" : "#9CA3AF");

        TextView i = new TextView(a);
        i.setText(icon);
        i.setTextSize(19);
        i.setGravity(Gravity.CENTER);
        i.setAlpha(active ? 1f : 0.7f);
        t.addView(i);

        TextView l = new TextView(a);
        l.setText(label);
        l.setTextSize(11);
        l.setTextColor(color);
        if (active) l.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        l.setGravity(Gravity.CENTER);
        t.addView(l);

        t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { go(a, current, target); }
        });
        return t;
    }

    private static void go(Activity a, int current, int target) {
        if (target == current) return;
        if (target == HOME) {
            Intent it = new Intent(a, MainActivity.class);
            it.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            a.startActivity(it);
        } else {
            Class<?> c;
            if (target == LOG) c = LogActivity.class;
            else if (target == SITES) c = SitesActivity.class;
            else c = SumActivity.class;
            a.startActivity(new Intent(a, c));
        }
        if (current != HOME) a.finish();
        a.overridePendingTransition(0, 0);
    }
}
