package com.profitcalc.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Vibrator;

import java.util.Calendar;
import java.util.Locale;

// تنبيه التارجت اليومي (مبروك + اهتزاز + إشعار) - بيستخدمه الشاشة الرئيسية
public class TargetHelper {

    static double parse(String t) {
        try {
            t = t.trim().replace(',', '.').replace('٫', '.');
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < t.length(); i++) {
                char ch = t.charAt(i);
                if (ch >= '٠' && ch <= '٩') sb.append((char) ('0' + (ch - '٠')));
                else sb.append(ch);
            }
            t = sb.toString();
            if (t.length() > 0 && !t.equals(".")) return Double.parseDouble(t);
        } catch (Exception e) {
        }
        return 0;
    }

    static String todayKey() {
        Calendar t = Calendar.getInstance();
        return String.format(Locale.US, "log_%04d-%02d-%02d",
            t.get(Calendar.YEAR), t.get(Calendar.MONTH) + 1, t.get(Calendar.DAY_OF_MONTH));
    }

    public static void checkReached(Activity a, SharedPreferences prefs) {
        String tk = todayKey();
        String doneKey = "target_done_" + tk;
        double target = parse(prefs.getString("daily_target", "0.50"));
        double v = parse(prefs.getString(tk, ""));
        boolean hit = target > 0 && v >= target - 1e-9;
        boolean notified = prefs.getBoolean(doneKey, false);
        if (hit && !notified) {
            prefs.edit().putBoolean(doneKey, true).apply();
            celebrate(a, v, target);
        } else if (!hit && notified) {
            prefs.edit().putBoolean(doneKey, false).apply();
        }
    }

    private static void celebrate(Activity a, double v, double target) {
        try {
            Vibrator vb = (Vibrator) a.getSystemService(Context.VIBRATOR_SERVICE);
            if (vb != null) vb.vibrate(new long[]{0, 200, 100, 200, 100, 400}, -1);
        } catch (Exception e) {
        }
        notifyTarget(a, v, target);
        if (a.isFinishing()) return;
        AlertDialog.Builder b = new AlertDialog.Builder(a);
        b.setTitle("🎉 مبروك!");
        b.setMessage(String.format(Locale.US,
            "حققت التارجت اليومي ✔\nربح النهاردة: %.2f $ من %.2f $", v, target));
        b.setPositiveButton("تمام", null);
        b.show();
    }

    private static void notifyTarget(Activity a, double v, double target) {
        try {
            NotificationManager nm = (NotificationManager) a.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            String channelId = "target_channel";
            Notification.Builder nb;
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(channelId,
                    "التارجت اليومي", NotificationManager.IMPORTANCE_HIGH);
                nm.createNotificationChannel(ch);
                nb = new Notification.Builder(a, channelId);
            } else {
                nb = new Notification.Builder(a);
                nb.setPriority(Notification.PRIORITY_HIGH);
                nb.setDefaults(Notification.DEFAULT_ALL);
            }
            Intent it = new Intent(a, LogActivity.class);
            it.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(a, 0, it, PendingIntent.FLAG_UPDATE_CURRENT);
            nb.setSmallIcon(R.drawable.ic_launcher);
            nb.setContentTitle("🎉 مبروك! حققت التارجت اليومي");
            nb.setContentText(String.format(Locale.US, "ربح النهاردة: %.2f $ من %.2f $", v, target));
            nb.setContentIntent(pi);
            nb.setAutoCancel(true);
            nm.notify(1001, nb.build());
        } catch (Exception e) {
        }
    }
}
