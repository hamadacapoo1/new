package com.profitcalc.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.content.DialogInterface;
import android.widget.Toast;
import android.view.MotionEvent;
import android.view.inputmethod.InputMethodManager;
import android.os.Vibrator;
import android.view.WindowManager;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.view.Window;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Calendar;
import java.util.Locale;

public class LogActivity extends Activity {

    private static final String PREFS = "profitcalc";

    private static final String[] MONTHS = {
        "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
        "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
    };
    // Calendar.DAY_OF_WEEK: 1 = الأحد
    private static final String[] DAYS = {
        "", "الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"
    };

    private static final int DAYS_PER_ROW = 7;

    private SharedPreferences prefs;
    private int year, month; // month: 0..11
    private TextView tvMonth, tvTotalUsd, tvTotalEgp, tvCount, tvRate;
    private LinearLayout list;

    // التارجت اليومي
    private static final String KEY_TARGET = "daily_target";
    private static final String DEFAULT_TARGET = "0.50";
    private EditText targetInput;
    private TextView tvProgress;
    private LinearLayout[] cells = new LinearLayout[32];
    private boolean[] todayFlag = new boolean[32];
    private Handler handler = new Handler();
    private Runnable targetCheck = new Runnable() {
        public void run() { checkTargetReached(true); }
    };

    private Dialog calcDlg;
    private View focusHolder;

    // الآلة الحاسبة
    private StringBuilder calcBuf = new StringBuilder();
    private TextView calcExprTv, calcResTv;
    private boolean justEvaluated = false;
    private String src;
    private int pos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        Calendar now = Calendar.getInstance();
        year = now.get(Calendar.YEAR);
        month = now.get(Calendar.MONTH);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#000000"));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(dp(8), dp(16), dp(8), dp(8));
        root.setFocusable(true);
        root.setFocusableInTouchMode(true);
        focusHolder = root;

        // سعر الدولار في أول الشاشة في النص
        tvRate = new TextView(this);
        tvRate.setTextSize(14);
        tvRate.setTypeface(Typeface.DEFAULT_BOLD);
        tvRate.setTextColor(Color.parseColor("#34D399"));
        tvRate.setGravity(Gravity.CENTER);
        tvRate.setBackground(box("#0A2E22", "#34D399", 20));
        tvRate.setPadding(dp(16), dp(6), dp(16), dp(6));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT);
        rp.gravity = Gravity.CENTER_HORIZONTAL;
        rp.setMargins(0, 0, 0, dp(10));
        root.addView(tvRate, rp);
        updateRate();

        TextView title = new TextView(this);
        title.setText("سجل الأرباح اليومي");
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(Color.parseColor("#FFFFFF"));
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap(0, 0, 0, 12));

        // شريط الشهر
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        nav.setGravity(Gravity.CENTER_VERTICAL);

        Button prev = makeButton("السابق", "#374151");
        prev.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { changeMonth(-1); }
        });
        Button next = makeButton("التالي", "#374151");
        next.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { changeMonth(1); }
        });

        tvMonth = new TextView(this);
        tvMonth.setTextSize(18);
        tvMonth.setTypeface(Typeface.DEFAULT_BOLD);
        tvMonth.setTextColor(Color.parseColor("#60A5FA"));
        tvMonth.setGravity(Gravity.CENTER);

        nav.addView(prev, new LinearLayout.LayoutParams(0, dp(44), 1f));
        nav.addView(tvMonth, new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1.4f));
        nav.addView(next, new LinearLayout.LayoutParams(0, dp(44), 1f));
        root.addView(nav, matchWrap(0, 0, 0, 12));

        // كارت الإجمالي
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(box("#1A1A1A", "#34D399", 12));
        card.setPadding(dp(14), dp(12), dp(14), dp(12));

        TextView totalLabel = new TextView(this);
        totalLabel.setText("إجمالي أرباح الشهر");
        totalLabel.setTextSize(15);
        totalLabel.setTextColor(Color.parseColor("#9CA3AF"));
        card.addView(totalLabel);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        row.setPadding(0, dp(8), 0, 0);

        tvTotalUsd = makeValueBox("#60A5FA", "#0F2747");
        tvTotalEgp = makeValueBox("#34D399", "#0A2E22");
        LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        p1.setMargins(0, 0, dp(6), 0);
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        p2.setMargins(dp(6), 0, 0, 0);
        row.addView(tvTotalUsd, p1);
        row.addView(tvTotalEgp, p2);
        card.addView(row);

        tvCount = new TextView(this);
        tvCount.setTextSize(13);
        tvCount.setTextColor(Color.parseColor("#9CA3AF"));
        tvCount.setPadding(0, dp(8), 0, 0);
        card.addView(tvCount);

        root.addView(card, matchWrap(0, 0, 0, 10));

        // كارت التارجت اليومي
        LinearLayout tCard = new LinearLayout(this);
        tCard.setOrientation(LinearLayout.VERTICAL);
        tCard.setBackground(box("#1A1A1A", "#F472B6", 12));
        tCard.setPadding(dp(14), dp(8), dp(14), dp(8));

        LinearLayout tRow = new LinearLayout(this);
        tRow.setOrientation(LinearLayout.HORIZONTAL);
        tRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        tRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView tLabel = new TextView(this);
        tLabel.setText("🎯 التارجت اليومي ($)");
        tLabel.setTextSize(15);
        tLabel.setTypeface(Typeface.DEFAULT_BOLD);
        tLabel.setTextColor(Color.parseColor("#F472B6"));
        tRow.addView(tLabel, new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        targetInput = new EditText(this);
        targetInput.setHint("0.50");
        targetInput.setText(prefs.getString(KEY_TARGET, DEFAULT_TARGET));
        targetInput.setTextSize(15);
        targetInput.setSingleLine(true);
        targetInput.setTextColor(Color.WHITE);
        targetInput.setHintTextColor(Color.parseColor("#6B7280"));
        targetInput.setGravity(Gravity.CENTER);
        targetInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        targetInput.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        targetInput.setBackground(box("#0F0F0F", "#444444", 8));
        targetInput.setPadding(dp(8), dp(4), dp(8), dp(4));
        tRow.addView(targetInput, new LinearLayout.LayoutParams(dp(90),
            LinearLayout.LayoutParams.WRAP_CONTENT));
        tCard.addView(tRow);

        tvProgress = new TextView(this);
        tvProgress.setTextSize(13);
        tvProgress.setGravity(Gravity.CENTER);
        tvProgress.setPadding(0, dp(6), 0, 0);
        tCard.addView(tvProgress);

        targetInput.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c2) {}
            public void onTextChanged(CharSequence s, int a, int b, int c2) {}
            public void afterTextChanged(Editable s) {
                prefs.edit().putString(KEY_TARGET, s.toString().trim()).apply();
                refreshAllCells();
                updateProgress();
                checkTargetReached(false);
                handler.removeCallbacks(targetCheck);
                handler.postDelayed(targetCheck, 1200);
            }
        });

        root.addView(tCard, matchWrap(0, 0, 0, 10));

        // قائمة الأيام
        ScrollView scroll = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        // زرار الآلة الحاسبة العايم
        FrameLayout frame = new FrameLayout(this);
        frame.addView(root, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        ImageView fab = new ImageView(this);
        fab.setImageResource(R.drawable.ic_calc);
        fab.setScaleType(ImageView.ScaleType.FIT_CENTER);
        fab.setPadding(dp(15), dp(15), dp(15), dp(15));
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Color.parseColor("#059669"));
        circle.setStroke(dp(2), Color.parseColor("#34D399"));
        fab.setBackground(circle);
        fab.setElevation(dp(8));
        fab.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { toggleCalculator(); }
        });
        FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(dp(60), dp(60));
        fp.gravity = Gravity.BOTTOM | Gravity.RIGHT;
        fp.setMargins(dp(16), dp(16), dp(16), dp(24));
        frame.addView(fab, fp);

        setContentView(BottomNav.wrap(this, frame, BottomNav.LOG));
        buildList();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateRate();
        updateTotal();
        updateProgress();
    }

    // الضغط في أي مكان فاضي بيخرجك من وضع الكتابة
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev.getAction() == MotionEvent.ACTION_DOWN) {
            View f = getCurrentFocus();
            if (f instanceof EditText) {
                int[] loc = new int[2];
                f.getLocationOnScreen(loc);
                float x = ev.getRawX(), y = ev.getRawY();
                boolean inside = x >= loc[0] && x <= loc[0] + f.getWidth()
                    && y >= loc[1] && y <= loc[1] + f.getHeight();
                if (!inside) {
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm != null) imm.hideSoftInputFromWindow(f.getWindowToken(), 0);
                    f.clearFocus();
                    if (focusHolder != null) focusHolder.requestFocus();
                }
            }
        }
        return super.dispatchTouchEvent(ev);
    }

    @Override
    protected void onPause() {
        super.onPause();
        // لو خرجت من الشاشة قبل ما الرسالة تظهر، ابعتلك إشعار
        handler.removeCallbacks(targetCheck);
        Calendar t = Calendar.getInstance();
        String doneKey = "target_done_" + keyFor(t.get(Calendar.YEAR),
            t.get(Calendar.MONTH), t.get(Calendar.DAY_OF_MONTH));
        double target = getTarget();
        double v = todayValue();
        if (target > 0 && v >= target - 1e-9 && !prefs.getBoolean(doneKey, false)) {
            prefs.edit().putBoolean(doneKey, true).apply();
            sendTargetNotification(v, target);
        }
    }

    private void sendTargetNotification(double v, double target) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            String channelId = "target_channel";
            Notification.Builder nb;
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(channelId,
                    "التارجت اليومي", NotificationManager.IMPORTANCE_HIGH);
                nm.createNotificationChannel(ch);
                nb = new Notification.Builder(this, channelId);
            } else {
                nb = new Notification.Builder(this);
                nb.setPriority(Notification.PRIORITY_HIGH);
                nb.setDefaults(Notification.DEFAULT_ALL);
            }
            Intent it = new Intent(this, LogActivity.class);
            it.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_UPDATE_CURRENT);
            nb.setSmallIcon(R.drawable.ic_launcher);
            nb.setContentTitle("🎉 مبروك! حققت التارجت اليومي");
            nb.setContentText(String.format(Locale.US, "ربح النهاردة: %.2f $ من %.2f $", v, target));
            nb.setContentIntent(pi);
            nb.setAutoCancel(true);
            nm.notify(1001, nb.build());
        } catch (Exception e) {
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(targetCheck);
        if (calcDlg != null && calcDlg.isShowing()) calcDlg.dismiss();
        super.onDestroy();
    }

    // ================= التارجت اليومي =================

    private double getTarget() {
        return parse(prefs.getString(KEY_TARGET, DEFAULT_TARGET));
    }

    private String keyFor(int y, int m, int d) {
        return String.format(Locale.US, "log_%04d-%02d-%02d", y, m + 1, d);
    }

    private double todayValue() {
        Calendar t = Calendar.getInstance();
        return parse(prefs.getString(
            keyFor(t.get(Calendar.YEAR), t.get(Calendar.MONTH), t.get(Calendar.DAY_OF_MONTH)), ""));
    }

    private void updateProgress() {
        if (tvProgress == null) return;
        double target = getTarget();
        double v = todayValue();
        if (target <= 0) {
            tvProgress.setTextColor(Color.parseColor("#9CA3AF"));
            tvProgress.setText("اكتب تارجت يومي عشان أعرفك لما تحققه");
        } else if (v >= target - 1e-9) {
            tvProgress.setTextColor(Color.parseColor("#34D399"));
            tvProgress.setText(String.format(Locale.US,
                "✅ حققت تارجت النهاردة!  %.2f / %.2f $", v, target));
        } else {
            tvProgress.setTextColor(Color.parseColor("#FBBF24"));
            tvProgress.setText(String.format(Locale.US,
                "ربح النهاردة: %.2f / %.2f $ — فاضل %.2f $", v, target, target - v));
        }
    }

    private void styleCell(int d) {
        LinearLayout cell = cells[d];
        if (cell == null) return;
        double target = getTarget();
        double v = parse(prefs.getString(key(d), ""));
        boolean hit = target > 0 && v >= target - 1e-9;
        if (hit) {
            cell.setBackground(box("#052E1B", "#34D399", 10));
        } else {
            cell.setBackground(box(todayFlag[d] ? "#3B2F0B" : "#1A1A1A",
                todayFlag[d] ? "#D97706" : "#333333", 10));
        }
        cell.setPadding(dp(1), dp(6), dp(1), dp(6));
    }

    private void refreshAllCells() {
        for (int d = 1; d < cells.length; d++) styleCell(d);
    }

    // بيعرّفك لما تحقق التارجت (مرة واحدة في اليوم)
    private void checkTargetReached(boolean showDialog) {
        Calendar t = Calendar.getInstance();
        String doneKey = "target_done_" + keyFor(t.get(Calendar.YEAR),
            t.get(Calendar.MONTH), t.get(Calendar.DAY_OF_MONTH));
        double target = getTarget();
        double v = todayValue();
        boolean hit = target > 0 && v >= target - 1e-9;
        boolean notified = prefs.getBoolean(doneKey, false);
        if (hit && !notified && showDialog) {
            prefs.edit().putBoolean(doneKey, true).apply();
            celebrate(v, target);
        } else if (!hit && notified) {
            prefs.edit().putBoolean(doneKey, false).apply();
        }
    }

    private void celebrate(double v, double target) {
        try {
            Vibrator vb = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vb != null) vb.vibrate(new long[]{0, 200, 100, 200, 100, 400}, -1);
        } catch (Exception e) {
        }
        sendTargetNotification(v, target);
        if (isFinishing()) return;
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("🎉 مبروك!");
        b.setMessage(String.format(Locale.US,
            "حققت التارجت اليومي ✔\nربح النهاردة: %.2f $ من %.2f $", v, target));
        b.setPositiveButton("تمام", null);
        b.show();
    }

    private void updateRate() {
        double rate = parse(prefs.getString("rate", "55.80"));
        tvRate.setText(String.format(Locale.US, "سعر الدولار: %.2f ج.م", rate));
    }

    private void changeMonth(int delta) {
        month += delta;
        if (month < 0) { month = 11; year--; }
        if (month > 11) { month = 0; year++; }
        buildList();
    }

    private String key(int day) {
        return String.format(Locale.US, "log_%04d-%02d-%02d", year, month + 1, day);
    }

    private void buildList() {
        tvMonth.setText(MONTHS[month] + " " + year);
        list.removeAllViews();

        Calendar c = Calendar.getInstance();
        c.set(year, month, 1);
        int daysInMonth = c.getActualMaximum(Calendar.DAY_OF_MONTH);

        Calendar today = Calendar.getInstance();
        LinearLayout gridRow = null;
        for (int i = 0; i < cells.length; i++) { cells[i] = null; todayFlag[i] = false; }

        for (int d = 1; d <= daysInMonth; d++) {
            c.set(year, month, d);
            String dayName = DAYS[c.get(Calendar.DAY_OF_WEEK)];

            boolean isToday = today.get(Calendar.YEAR) == year
                && today.get(Calendar.MONTH) == month
                && today.get(Calendar.DAY_OF_MONTH) == d;

            // كل 7 أيام في صف
            if ((d - 1) % DAYS_PER_ROW == 0) {
                gridRow = new LinearLayout(this);
                gridRow.setOrientation(LinearLayout.HORIZONTAL);
                gridRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
                list.addView(gridRow, matchWrap(0, 0, 0, 6));
            }

            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(dp(1), dp(6), dp(1), dp(6));
            cells[d] = cell;
            todayFlag[d] = isToday;

            TextView label = new TextView(this);
            label.setText(dayName);
            label.setTextSize(10);
            label.setSingleLine(true);
            label.setGravity(Gravity.CENTER);
            label.setTextColor(Color.parseColor("#9CA3AF"));

            TextView num = new TextView(this);
            num.setText(String.valueOf(d));
            num.setTextSize(15);
            num.setGravity(Gravity.CENTER);
            num.setTypeface(Typeface.DEFAULT_BOLD);
            num.setTextColor(isToday ? Color.parseColor("#FBBF24") : Color.parseColor("#E5E7EB"));

            final int day = d;
            EditText et = new EditText(this);
            et.setHint("0.00");
            et.setTextSize(11);
            et.setSingleLine(true);
            et.setTextColor(Color.WHITE);
            et.setHintTextColor(Color.parseColor("#6B7280"));
            et.setGravity(Gravity.CENTER);
            et.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            et.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            et.setPadding(0, dp(4), 0, dp(4));
            et.setText(prefs.getString(key(d), ""));
            et.addTextChangedListener(new TextWatcher() {
                public void beforeTextChanged(CharSequence s, int a, int b, int c2) {}
                public void onTextChanged(CharSequence s, int a, int b, int c2) {}
                public void afterTextChanged(Editable s) {
                    String t = s.toString().trim();
                    if (t.length() == 0) {
                        prefs.edit().remove(key(day)).apply();
                    } else {
                        prefs.edit().putString(key(day), t).apply();
                    }
                    updateTotal();
                    styleCell(day);
                    updateProgress();
                    if (todayFlag[day]) {
                        checkTargetReached(false);
                        handler.removeCallbacks(targetCheck);
                        handler.postDelayed(targetCheck, 1200);
                    }
                }
            });

            cell.addView(label, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
            cell.addView(num, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
            cell.addView(et, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            cp.setMargins(dp(2), 0, dp(2), 0);
            gridRow.addView(cell, cp);
        }
        // تكملة الصف الأخير بخانات فاضية عشان الأحجام تفضل متساوية
        if (gridRow != null) {
            int left = gridRow.getChildCount();
            for (int k = left; k < DAYS_PER_ROW; k++) {
                LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
                ep.setMargins(dp(2), 0, dp(2), 0);
                gridRow.addView(new View(this), ep);
            }
        }
        // مسافة فاضية في الآخر عشان زرار الحاسبة ما يغطيش آخر الأيام
        list.addView(new View(this), new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(90)));
        updateTotal();
        refreshAllCells();
        updateProgress();
    }

    private void updateTotal() {
        Calendar c = Calendar.getInstance();
        c.set(year, month, 1);
        int daysInMonth = c.getActualMaximum(Calendar.DAY_OF_MONTH);

        double sum = 0;
        int count = 0;
        for (int d = 1; d <= daysInMonth; d++) {
            String v = prefs.getString(key(d), "");
            if (v.length() > 0) {
                double x = parse(v);
                sum += x;
                count++;
            }
        }
        double rate = parse(prefs.getString("rate", "55.80"));
        tvTotalUsd.setText(String.format(Locale.US, "%,.2f $", sum));
        tvTotalEgp.setText(String.format(Locale.US, "%,.2f ج.م", sum * rate));
        tvCount.setText("عدد الأيام المسجلة: " + count + " من " + daysInMonth);
    }

    private double parse(String t) {
        try {
            t = t.trim().replace(',', '.').replace('٫', '.');
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < t.length(); i++) {
                char ch = t.charAt(i);
                if (ch >= '٠' && ch <= '٩') {
                    sb.append((char) ('0' + (ch - '٠')));
                } else {
                    sb.append(ch);
                }
            }
            t = sb.toString();
            if (t.length() > 0 && !t.equals(".")) {
                return Double.parseDouble(t);
            }
        } catch (Exception e) {
        }
        return 0;
    }

    // ================= الآلة الحاسبة =================

    private void toggleCalculator() {
        if (calcDlg != null && calcDlg.isShowing()) {
            calcDlg.dismiss();
        } else {
            showCalculator();
        }
    }

    private void showCalculator() {
        calcDlg = new Dialog(this);
        calcDlg.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        box.setBackground(box("#111111", "#333333", 14));
        box.setPadding(dp(8), dp(8), dp(8), dp(8));

        // شريط السحب: امسكه وحرّك الحاسبة في أي مكان
        TextView drag = new TextView(this);
        drag.setText("⠿  اسحب من هنا عشان تحرّكها  ⠿");
        drag.setTextSize(11);
        drag.setTextColor(Color.parseColor("#9CA3AF"));
        drag.setGravity(Gravity.CENTER);
        drag.setBackground(box("#1F2937", "#1F2937", 8));
        box.addView(drag, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(24)));

        calcExprTv = new TextView(this);
        calcExprTv.setTextSize(17);
        calcExprTv.setTextColor(Color.WHITE);
        calcExprTv.setGravity(Gravity.RIGHT);
        calcExprTv.setSingleLine(true);
        box.addView(calcExprTv, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        calcResTv = new TextView(this);
        calcResTv.setTextSize(20);
        calcResTv.setTypeface(Typeface.DEFAULT_BOLD);
        calcResTv.setTextColor(Color.parseColor("#34D399"));
        calcResTv.setGravity(Gravity.RIGHT);
        calcResTv.setSingleLine(true);
        calcResTv.setMinHeight(dp(30));
        box.addView(calcResTv, matchWrap(0, 0, 0, 6));

        String[][] rows = {
            {"C", "⌫", "÷", "×"},
            {"7", "8", "9", "−"},
            {"4", "5", "6", "+"},
            {"1", "2", "3", "."}
        };
        for (int r = 0; r < rows.length; r++) {
            LinearLayout line = new LinearLayout(this);
            line.setOrientation(LinearLayout.HORIZONTAL);
            for (int c = 0; c < 4; c++) {
                line.addView(makeKey(rows[r][c]), keyParams(1f));
            }
            box.addView(line, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(42)));
        }
        LinearLayout last = new LinearLayout(this);
        last.setOrientation(LinearLayout.HORIZONTAL);
        last.addView(makeKey("0"), keyParams(2f));
        last.addView(makeKey("="), keyParams(2f));
        box.addView(last, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(42)));

        Button send = new Button(this);
        send.setText("⬆ ودّي الناتج لليوم");
        send.setAllCaps(false);
        send.setTextSize(14);
        send.setTextColor(Color.WHITE);
        send.setPadding(0, 0, 0, 0);
        send.setMinHeight(0);
        send.setMinimumHeight(0);
        send.setBackground(box("#2563EB", "#2563EB", 10));
        send.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { confirmSendToToday(); }
        });
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(40));
        sp.setMargins(dp(2), dp(4), dp(2), dp(2));
        box.addView(send, sp);

        calcDlg.setContentView(box);
        Window w = calcDlg.getWindow();
        w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        // من غير تعتيم، ومن غير ما تسرق الفوكس، وتقدر تلمس الصفحة اللي ورا
        w.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        w.addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
            | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
        calcDlg.setCanceledOnTouchOutside(false);
        calcDlg.show();

        final int cw = dp(210);
        box.measure(View.MeasureSpec.makeMeasureSpec(cw, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        final int ch = box.getMeasuredHeight();
        final int sw = getResources().getDisplayMetrics().widthPixels;
        final int sh = getResources().getDisplayMetrics().heightPixels;

        final WindowManager.LayoutParams lp = w.getAttributes();
        lp.width = cw;
        lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        int sx = prefs.getInt("calc_x", -1);
        int sy = prefs.getInt("calc_y", -1);
        if (sx < 0 || sy < 0) {
            // أول مرة: تحت يمين الشاشة فوق زرار الحاسبة
            sx = sw - cw - dp(12);
            sy = sh - ch - dp(96) - dp(40) - dp(56);
        }
        lp.x = Math.max(0, Math.min(sx, sw - cw));
        lp.y = Math.max(0, Math.min(sy, sh - ch));
        w.setAttributes(lp);

        final Window fw = w;
        final float[] st = new float[4];
        drag.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent ev) {
                switch (ev.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        st[0] = ev.getRawX();
                        st[1] = ev.getRawY();
                        st[2] = lp.x;
                        st[3] = lp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = (int) Math.max(0, Math.min(st[2] + (ev.getRawX() - st[0]), sw - cw));
                        lp.y = (int) Math.max(0, Math.min(st[3] + (ev.getRawY() - st[1]), sh - ch));
                        fw.setAttributes(lp);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        prefs.edit().putInt("calc_x", lp.x).putInt("calc_y", lp.y).apply();
                        return true;
                }
                return false;
            }
        });

        updateCalcDisplay();
    }

    // بعت الناتج لخانة النهارده (بعد رسالة تأكيد)
    private void confirmSendToToday() {
        if (calcBuf.length() == 0) {
            Toast.makeText(this, "اكتب رقم الأول", Toast.LENGTH_SHORT).show();
            return;
        }
        double result;
        try {
            result = evalExpr(calcBuf.toString());
        } catch (Exception e) {
            Toast.makeText(this, "العملية مش مظبوطة", Toast.LENGTH_SHORT).show();
            return;
        }
        final String val = fmtNum(result);
        Calendar t = Calendar.getInstance();
        final int ty = t.get(Calendar.YEAR), tm = t.get(Calendar.MONTH), td = t.get(Calendar.DAY_OF_MONTH);
        final String tk = keyFor(ty, tm, td);
        String old = prefs.getString(tk, "");
        String msg = "تسجّل " + val + " $ كربح النهاردة؟";
        if (old.length() > 0) {
            msg += "\nالقيمة الحالية (" + old + ") هتتبدل.";
        }
        new AlertDialog.Builder(this)
            .setTitle("تأكيد")
            .setMessage(msg)
            .setPositiveButton("نعم", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int which) {
                    prefs.edit().putString(tk, val).apply();
                    if (year == ty && month == tm) {
                        buildList();
                    } else {
                        updateTotal();
                    }
                    updateProgress();
                    checkTargetReached(false);
                    handler.removeCallbacks(targetCheck);
                    handler.postDelayed(targetCheck, 600);
                    Toast.makeText(LogActivity.this, "تم التسجيل ✔", Toast.LENGTH_SHORT).show();
                }
            })
            .setNegativeButton("لا", null)
            .show();
    }

    private LinearLayout.LayoutParams keyParams(float weight) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.MATCH_PARENT, weight);
        p.setMargins(dp(2), dp(2), dp(2), dp(2));
        return p;
    }

    private Button makeKey(final String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(17);
        b.setTextColor(Color.WHITE);
        b.setPadding(0, 0, 0, 0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        String bg = "#1F2937";
        if (label.equals("C")) bg = "#DC2626";
        else if (label.equals("⌫")) bg = "#4B5563";
        else if (label.equals("=")) bg = "#059669";
        else if (isOp(label.charAt(0))) bg = "#D97706";
        b.setBackground(box(bg, bg, 10));
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { onCalcKey(label); }
        });
        return b;
    }

    private boolean isOp(char c) {
        return c == '÷' || c == '×' || c == '−' || c == '+';
    }

    private void onCalcKey(String k) {
        char ch = k.charAt(0);
        if (k.equals("C")) {
            calcBuf.setLength(0);
            justEvaluated = false;
        } else if (k.equals("⌫")) {
            if (calcBuf.length() > 0) {
                calcBuf.deleteCharAt(calcBuf.length() - 1);
            }
            justEvaluated = false;
        } else if (k.equals("=")) {
            try {
                double v = evalExpr(calcBuf.toString());
                calcBuf.setLength(0);
                calcBuf.append(fmtNum(v));
                justEvaluated = true;
            } catch (Exception e) {
                if (calcBuf.length() > 0) {
                    calcExprTv.setText(calcBuf.toString());
                    calcResTv.setText("خطأ");
                    return;
                }
            }
        } else if (isOp(ch)) {
            justEvaluated = false;
            if (calcBuf.length() == 0) {
                if (ch == '−') calcBuf.append(ch);
            } else {
                char lastCh = calcBuf.charAt(calcBuf.length() - 1);
                if (isOp(lastCh)) {
                    if (calcBuf.length() > 1) {
                        calcBuf.setCharAt(calcBuf.length() - 1, ch);
                    }
                } else {
                    calcBuf.append(ch);
                }
            }
        } else if (k.equals(".")) {
            if (justEvaluated) { calcBuf.setLength(0); justEvaluated = false; }
            int start = 0;
            for (int i = calcBuf.length() - 1; i >= 0; i--) {
                if (isOp(calcBuf.charAt(i))) { start = i + 1; break; }
            }
            String seg = calcBuf.substring(start);
            if (seg.indexOf('.') < 0) {
                if (seg.length() == 0) calcBuf.append("0");
                calcBuf.append(".");
            }
        } else {
            // رقم
            if (justEvaluated) { calcBuf.setLength(0); justEvaluated = false; }
            if (calcBuf.length() < 40) {
                calcBuf.append(k);
            }
        }
        updateCalcDisplay();
    }

    private void updateCalcDisplay() {
        if (calcExprTv == null) return;
        calcExprTv.setText(calcBuf.length() == 0 ? "0" : calcBuf.toString());
        boolean hasOp = false;
        for (int i = 1; i < calcBuf.length(); i++) {
            if (isOp(calcBuf.charAt(i))) { hasOp = true; break; }
        }
        String res = "";
        if (hasOp) {
            try {
                res = "= " + fmtNum(evalExpr(calcBuf.toString()));
            } catch (Exception e) {
                res = "";
            }
        }
        calcResTv.setText(res);
    }

    private String fmtNum(double v) {
        if (v == Math.rint(v) && Math.abs(v) < 1e12) {
            return String.valueOf((long) v);
        }
        BigDecimal bd = new BigDecimal(v).setScale(8, RoundingMode.HALF_UP).stripTrailingZeros();
        return bd.toPlainString();
    }

    private double evalExpr(String s) {
        src = s.replace('÷', '/').replace('×', '*').replace('−', '-');
        pos = 0;
        double v = parseExpr();
        if (pos != src.length()) throw new RuntimeException("bad");
        return v;
    }

    private double parseExpr() {
        double v = parseTerm();
        while (pos < src.length()) {
            char c = src.charAt(pos);
            if (c == '+') { pos++; v += parseTerm(); }
            else if (c == '-') { pos++; v -= parseTerm(); }
            else break;
        }
        return v;
    }

    private double parseTerm() {
        double v = parseFactor();
        while (pos < src.length()) {
            char c = src.charAt(pos);
            if (c == '*') { pos++; v *= parseFactor(); }
            else if (c == '/') {
                pos++;
                double d = parseFactor();
                if (d == 0) throw new RuntimeException("div0");
                v /= d;
            } else break;
        }
        return v;
    }

    private double parseFactor() {
        if (pos < src.length() && src.charAt(pos) == '-') {
            pos++;
            return -parseFactor();
        }
        int start = pos;
        while (pos < src.length()
            && (Character.isDigit(src.charAt(pos)) || src.charAt(pos) == '.')) {
            pos++;
        }
        if (start == pos) throw new RuntimeException("num");
        return Double.parseDouble(src.substring(start, pos));
    }

    private Button makeButton(String text, String color) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(14);
        b.setTextColor(Color.WHITE);
        b.setBackground(box(color, color, 10));
        return b;
    }

    private TextView makeValueBox(String color, String bg) {
        TextView v = new TextView(this);
        v.setText("0.00");
        v.setTextSize(18);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setTextColor(Color.parseColor(color));
        v.setGravity(Gravity.CENTER);
        v.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        v.setPadding(dp(8), dp(12), dp(8), dp(12));
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.parseColor(bg));
        g.setCornerRadius(dp(10));
        v.setBackground(g);
        return v;
    }

    private GradientDrawable box(String fill, String stroke, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.parseColor(fill));
        g.setCornerRadius(dp(radius));
        g.setStroke(dp(2), Color.parseColor(stroke));
        return g;
    }

    private LinearLayout.LayoutParams matchWrap(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
