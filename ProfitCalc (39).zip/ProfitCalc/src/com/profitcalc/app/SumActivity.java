package com.profitcalc.app;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.net.Uri;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Locale;

public class SumActivity extends Activity {

    private static final String PREFS = "profitcalc";
    private static final String KEY_PREFIX = "sum_field_";
    private static final String KEY_SITE = "sum_site_";
    private static final String KEY_SITES = "sites";
    private static final String NONE = "— اختر موقع —";
    private static final int COUNT = 7;

    private SharedPreferences prefs;
    private EditText[] fields = new EditText[COUNT];
    private Spinner[] spinners = new Spinner[COUNT];
    private ArrayList<String> siteNames = new ArrayList<String>();
    private ArrayList<String> siteUrls = new ArrayList<String>();
    private ArrayList<Bitmap> siteIcons = new ArrayList<Bitmap>();
    private ArrayList<ArrayAdapter<String>> adapters = new ArrayList<ArrayAdapter<String>>();
    private boolean alive = true;
    private View focusHolder;
    private static final String[] PALETTE = {
        "#60A5FA", "#34D399", "#FBBF24", "#F87171", "#A78BFA", "#F472B6"
    };
    private TextView totalView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        loadSiteNames();

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.parseColor("#000000"));
        scroll.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(24), dp(18), dp(24));
        root.setFocusableInTouchMode(true);
        focusHolder = root;
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("الجمع");
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER);
        root.addView(title, params(0, 0, 0, 6));

        TextView sub = new TextView(this);
        sub.setText("اكتب الأرقام في الخانات والمجموع بيظهر تحت");
        sub.setTextSize(12);
        sub.setTextColor(Color.parseColor("#9CA3AF"));
        sub.setGravity(Gravity.CENTER);
        root.addView(sub, params(0, 0, 0, 18));

        TextWatcher watcher = new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            public void onTextChanged(CharSequence s, int a, int b, int c) { }
            public void afterTextChanged(Editable e) {
                save();
                updateTotal();
            }
        };

        for (int i = 0; i < COUNT; i++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

            TextView label = new TextView(this);
            label.setText(String.valueOf(i + 1));
            label.setTextSize(16);
            label.setTypeface(Typeface.DEFAULT_BOLD);
            label.setTextColor(Color.parseColor("#E5E7EB"));
            row.addView(label, new LinearLayout.LayoutParams(dp(26),
                LinearLayout.LayoutParams.WRAP_CONTENT));

            Spinner sp = makeSpinner(prefs.getString(KEY_SITE + i, ""));
            spinners[i] = sp;
            LinearLayout.LayoutParams spLp = new LinearLayout.LayoutParams(dp(145), dp(40));
            spLp.setMargins(0, 0, dp(8), 0);
            row.addView(sp, spLp);

            EditText et = new EditText(this);
            et.setHint("0");
            et.setHintTextColor(Color.parseColor("#6B7280"));
            et.setTextColor(Color.WHITE);
            et.setTextSize(18);
            et.setSingleLine(true);
            et.setInputType(InputType.TYPE_CLASS_NUMBER
                | InputType.TYPE_NUMBER_FLAG_DECIMAL
                | InputType.TYPE_NUMBER_FLAG_SIGNED);
            et.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            et.setGravity(Gravity.CENTER);
            et.setBackground(box("#1A1A1A", "#333333", 12));
            et.setPadding(dp(12), dp(10), dp(12), dp(10));
            et.setText(prefs.getString(KEY_PREFIX + i, ""));
            et.addTextChangedListener(watcher);
            fields[i] = et;
            row.addView(et, new LinearLayout.LayoutParams(dp(110),
                LinearLayout.LayoutParams.WRAP_CONTENT));

            root.addView(row, params(0, 0, 0, 10));
        }

        // خط فاصل
        View line = new View(this);
        line.setBackgroundColor(Color.parseColor("#2A2A2A"));
        root.addView(line, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(1)));
        ((LinearLayout.LayoutParams) line.getLayoutParams()).setMargins(0, dp(8), 0, dp(14));

        TextView totalLabel = new TextView(this);
        totalLabel.setText("المجموع");
        totalLabel.setTextSize(14);
        totalLabel.setTextColor(Color.parseColor("#9CA3AF"));
        totalLabel.setGravity(Gravity.CENTER);
        root.addView(totalLabel, params(0, 0, 0, 6));

        totalView = new TextView(this);
        totalView.setTextSize(32);
        totalView.setTypeface(Typeface.DEFAULT_BOLD);
        totalView.setTextColor(Color.parseColor("#34D399"));
        totalView.setGravity(Gravity.CENTER);
        totalView.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        totalView.setPadding(dp(12), dp(16), dp(12), dp(16));
        totalView.setBackground(box("#111111", "#34D399", 14));
        root.addView(totalView, params(0, 0, 0, 16));

        TextView clear = new TextView(this);
        clear.setText("مسح الكل");
        clear.setTextSize(14);
        clear.setTextColor(Color.parseColor("#F87171"));
        clear.setGravity(Gravity.CENTER);
        clear.setPadding(dp(12), dp(12), dp(12), dp(12));
        clear.setBackground(box("#111111", "#F87171", 12));
        clear.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                for (int i = 0; i < COUNT; i++) fields[i].setText("");
            }
        });
        root.addView(clear, params(0, 0, 0, 0));

        setContentView(BottomNav.wrap(this, scroll, BottomNav.SUM));
        updateTotal();
        fetchMissingIcons();
    }

    // الضغط في أي مكان برا خانات الكتابة بيقفل الكيبورد ويخرجك من وضع الكتابة
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev.getAction() == MotionEvent.ACTION_DOWN) {
            View f = getCurrentFocus();
            if (f instanceof EditText) {
                int x = (int) ev.getRawX();
                int y = (int) ev.getRawY();
                boolean insideField = false;
                Rect r = new Rect();
                for (int i = 0; i < COUNT; i++) {
                    if (fields[i] != null && fields[i].getGlobalVisibleRect(r)
                        && r.contains(x, y)) {
                        insideField = true;
                        break;
                    }
                }
                if (!insideField) {
                    f.clearFocus();
                    if (focusHolder != null) focusHolder.requestFocus();
                    InputMethodManager imm =
                        (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    if (imm != null) imm.hideSoftInputFromWindow(f.getWindowToken(), 0);
                }
            }
        }
        return super.dispatchTouchEvent(ev);
    }

    @Override
    protected void onDestroy() {
        alive = false;
        super.onDestroy();
    }

    private void save() {
        SharedPreferences.Editor ed = prefs.edit();
        for (int i = 0; i < COUNT; i++) {
            if (fields[i] != null) {
                ed.putString(KEY_PREFIX + i, fields[i].getText().toString());
            }
        }
        for (int i = 0; i < COUNT; i++) {
            if (spinners[i] != null) {
                int pos = spinners[i].getSelectedItemPosition();
                String name = (pos > 0 && pos <= siteNames.size()) ? siteNames.get(pos - 1) : "";
                ed.putString(KEY_SITE + i, name);
            }
        }
        ed.apply();
    }

    // ---------- المواقع ----------

    private void loadSiteNames() {
        siteNames.clear();
        siteUrls.clear();
        siteIcons.clear();
        try {
            JSONArray a = new JSONArray(prefs.getString(KEY_SITES, "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                String url = o.getString("u");
                siteNames.add(o.getString("n"));
                siteUrls.add(url);
                siteIcons.add(cachedIcon(url));
            }
        } catch (Exception e) {
        }
    }

    // ---------- أيقونات المواقع (نفس الكاش بتاع صفحة مواقعي) ----------

    private String hostOf(String url) {
        try {
            return Uri.parse(url).getHost();
        } catch (Exception e) {
            return null;
        }
    }

    private File iconFile(String url) {
        String host = hostOf(url);
        if (host == null) return null;
        return new File(getFilesDir(), "fav_" + Math.abs(host.hashCode()) + ".png");
    }

    private Bitmap cachedIcon(String url) {
        File f = iconFile(url);
        if (f != null && f.exists()) {
            return BitmapFactory.decodeFile(f.getAbsolutePath());
        }
        return null;
    }

    private void fetchMissingIcons() {
        for (int i = 0; i < siteUrls.size(); i++) {
            if (siteIcons.get(i) != null) continue;
            final int idx = i;
            final String host = hostOf(siteUrls.get(i));
            final File f = iconFile(siteUrls.get(i));
            if (host == null || f == null) continue;
            new Thread(new Runnable() {
                public void run() {
                    try {
                        URL u = new URL("https://www.google.com/s2/favicons?domain="
                            + host + "&sz=128");
                        HttpURLConnection c = (HttpURLConnection) u.openConnection();
                        c.setConnectTimeout(10000);
                        c.setReadTimeout(10000);
                        InputStream in = c.getInputStream();
                        FileOutputStream out = new FileOutputStream(f);
                        byte[] buf = new byte[4096];
                        int n;
                        while ((n = in.read(buf)) > 0) {
                            out.write(buf, 0, n);
                        }
                        out.close();
                        in.close();
                        final Bitmap b = BitmapFactory.decodeFile(f.getAbsolutePath());
                        if (b == null) {
                            f.delete();
                            return;
                        }
                        runOnUiThread(new Runnable() {
                            public void run() {
                                if (!alive || idx >= siteIcons.size()) return;
                                siteIcons.set(idx, b);
                                for (int k = 0; k < adapters.size(); k++) {
                                    adapters.get(k).notifyDataSetChanged();
                                }
                            }
                        });
                    } catch (Exception e) {
                        f.delete();
                    }
                }
            }).start();
        }
    }

    // ---------- القايمة المنسدلة ----------

    private View siteIcon(int siteIdx, int size) {
        Bitmap bmp = siteIcons.get(siteIdx);
        if (bmp != null) {
            ImageView img = new ImageView(this);
            img.setScaleType(ImageView.ScaleType.FIT_CENTER);
            img.setImageBitmap(bmp);
            return img;
        }
        String name = siteNames.get(siteIdx);
        String color = PALETTE[Math.abs(name.hashCode()) % PALETTE.length];
        TextView t = new TextView(this);
        String trimmed = name.trim();
        t.setText(trimmed.length() == 0 ? "؟" : trimmed.substring(0, 1).toUpperCase());
        t.setTextSize(13);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(Color.parseColor(color));
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.parseColor("#1A1A1A"));
        g.setCornerRadius(dp(8));
        g.setStroke(dp(1), Color.parseColor(color));
        t.setBackground(g);
        return t;
    }

    private View itemRow(int position, boolean dropdown) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        if (dropdown) {
            row.setBackgroundColor(Color.parseColor("#1A1A1A"));
            row.setPadding(dp(12), dp(10), dp(12), dp(10));
        } else {
            row.setPadding(dp(4), 0, dp(4), 0);
        }

        if (position > 0 && position - 1 < siteNames.size()) {
            int size = dropdown ? dp(30) : dp(24);
            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(size, size);
            ilp.setMarginEnd(dp(8));
            row.addView(siteIcon(position - 1, size), ilp);
        }

        TextView tv = new TextView(this);
        tv.setText(position == 0 ? NONE : siteNames.get(position - 1));
        tv.setTextSize(dropdown ? 15 : 13);
        tv.setTextColor(position == 0 ? Color.parseColor("#9CA3AF") : Color.WHITE);
        tv.setSingleLine(true);
        tv.setEllipsize(TextUtils.TruncateAt.END);
        row.addView(tv, new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        return row;
    }

    private Spinner makeSpinner(String savedName) {
        final ArrayList<String> items = new ArrayList<String>();
        items.add(NONE);
        items.addAll(siteNames);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
            android.R.layout.simple_spinner_item, items) {
            public View getView(int position, View convertView, ViewGroup parent) {
                return itemRow(position, false);
            }
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                return itemRow(position, true);
            }
        };
        adapters.add(adapter);

        Spinner sp = new Spinner(this);
        sp.setAdapter(adapter);
        sp.setBackground(box("#1A1A1A", "#333333", 12));
        sp.setPadding(dp(6), 0, dp(6), 0);
        sp.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sp.setDropDownWidth(dp(240));

        int sel = 0;
        if (savedName != null && savedName.length() > 0) {
            int idx = siteNames.indexOf(savedName);
            if (idx >= 0) sel = idx + 1;
        }
        sp.setSelection(sel);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                save();
            }
            public void onNothingSelected(AdapterView<?> p) { }
        });
        return sp;
    }

    private void updateTotal() {
        double sum = 0;
        for (int i = 0; i < COUNT; i++) {
            if (fields[i] == null) continue;
            sum += parse(fields[i].getText().toString());
        }
        DecimalFormat df = new DecimalFormat("#,##0.####",
            new DecimalFormatSymbols(Locale.US));
        totalView.setText(df.format(sum));
    }

    // بيقبل الأرقام العربية والفاصلة العربية كمان
    private double parse(String t) {
        t = t.trim();
        if (t.length() == 0) return 0;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (c >= '\u0660' && c <= '\u0669') c = (char) ('0' + (c - '\u0660'));
            else if (c >= '\u06F0' && c <= '\u06F9') c = (char) ('0' + (c - '\u06F0'));
            else if (c == ',' || c == '\u066B' || c == '\u066C') c = '.';
            sb.append(c);
        }
        try {
            return Double.parseDouble(sb.toString());
        } catch (Exception e) {
            return 0;
        }
    }

    private GradientDrawable box(String fill, String stroke, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.parseColor(fill));
        g.setCornerRadius(dp(radius));
        g.setStroke(dp(2), Color.parseColor(stroke));
        return g;
    }

    private LinearLayout.LayoutParams params(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
