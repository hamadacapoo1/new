package com.profitcalc.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class SitesActivity extends Activity {

    private static final String PREFS = "profitcalc";
    private static final String KEY_SITES = "sites";
    private static final int COLS = 5;
    private static final String[] PALETTE = {
        "#60A5FA", "#34D399", "#FBBF24", "#F87171", "#A78BFA", "#F472B6"
    };

    private SharedPreferences prefs;
    private LinearLayout grid;
    private TextView emptyHint;
    // كل عنصر: {الاسم, الرابط}
    private ArrayList<String[]> sites = new ArrayList<String[]>();
    private boolean alive = true;
    private int iconSize;

    // ---- حالة السحب لتغيير الترتيب ----
    private ArrayList<View> itemViews = new ArrayList<View>();
    private int dragIdx = -1;
    private int targetIdx = -1;
    private View dragView;
    private float downRawX, downRawY;
    private boolean dragMoved;
    private int[] rowBottoms = new int[0];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        load();

        // حجم الأيقونة بيتحسب على حسب عرض الشاشة عشان 5 في الصف يتساعوا
        int cell = (getResources().getDisplayMetrics().widthPixels - dp(28)) / COLS;
        iconSize = Math.min(cell - dp(8), dp(64));

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.parseColor("#000000"));
        scroll.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.setClipChildren(false);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(24), dp(14), dp(24));
        root.setClipChildren(false);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("مواقعي");
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap(0, 0, 0, 6));

        TextView sub = new TextView(this);
        sub.setText("اضغط على الأيقونة لفتح الموقع • اضغط مطولًا وحرّك لتغيير الترتيب • اضغط مطولًا وسيب للتعديل أو الحذف");
        sub.setTextSize(12);
        sub.setTextColor(Color.parseColor("#9CA3AF"));
        sub.setGravity(Gravity.CENTER);
        root.addView(sub, matchWrap(0, 0, 0, 18));

        grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        grid.setClipChildren(false);
        root.addView(grid, matchWrap(0, 0, 0, 0));

        emptyHint = new TextView(this);
        emptyHint.setText("لسه مفيش مواقع. اضغط على + لإضافة أول موقع.");
        emptyHint.setTextSize(14);
        emptyHint.setTextColor(Color.parseColor("#6B7280"));
        emptyHint.setGravity(Gravity.CENTER);
        root.addView(emptyHint, matchWrap(0, 16, 0, 0));

        setContentView(BottomNav.wrap(this, scroll, BottomNav.SITES));
        build();
    }

    @Override
    protected void onDestroy() {
        alive = false;
        super.onDestroy();
    }

    // ---------- التخزين ----------

    private void load() {
        sites.clear();
        try {
            JSONArray a = new JSONArray(prefs.getString(KEY_SITES, "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                sites.add(new String[] { o.getString("n"), o.getString("u") });
            }
        } catch (Exception e) {
        }
    }

    private void save() {
        try {
            JSONArray a = new JSONArray();
            for (int i = 0; i < sites.size(); i++) {
                JSONObject o = new JSONObject();
                o.put("n", sites.get(i)[0]);
                o.put("u", sites.get(i)[1]);
                a.put(o);
            }
            prefs.edit().putString(KEY_SITES, a.toString()).apply();
        } catch (Exception e) {
        }
    }

    // ---------- بناء الشبكة ----------

    private void build() {
        grid.removeAllViews();
        itemViews.clear();
        dragIdx = -1;
        dragView = null;
        emptyHint.setVisibility(sites.size() == 0 ? View.VISIBLE : View.GONE);

        int total = sites.size() + 1; // + خانة الإضافة
        int rows = (total + COLS - 1) / COLS;
        for (int r = 0; r < rows; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            row.setClipChildren(false);
            for (int c = 0; c < COLS; c++) {
                int idx = r * COLS + c;
                View item;
                if (idx < sites.size()) {
                    item = makeItem(idx);
                    itemViews.add(item);
                } else if (idx == sites.size()) {
                    item = makeAddItem();
                } else {
                    item = new View(this);
                }
                row.addView(item, new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            }
            grid.addView(row, matchWrap(0, 0, 0, 14));
        }
    }

    private View makeItem(final int idx) {
        String name = sites.get(idx)[0];
        String url = sites.get(idx)[1];
        String color = PALETTE[Math.abs(name.hashCode()) % PALETTE.length];

        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER_HORIZONTAL);
        item.setPadding(dp(2), dp(4), dp(2), dp(4));

        FrameLayout icon = new FrameLayout(this);
        icon.setBackground(box("#1A1A1A", color, 14));

        TextView letter = new TextView(this);
        letter.setText(firstLetter(name));
        letter.setTextSize(22);
        letter.setTypeface(Typeface.DEFAULT_BOLD);
        letter.setTextColor(Color.parseColor(color));
        letter.setGravity(Gravity.CENTER);
        icon.addView(letter, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT));

        ImageView img = new ImageView(this);
        img.setScaleType(ImageView.ScaleType.FIT_CENTER);
        img.setPadding(dp(10), dp(10), dp(10), dp(10));
        img.setVisibility(View.GONE);
        icon.addView(img, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT));

        item.addView(icon, new LinearLayout.LayoutParams(iconSize, iconSize));

        TextView label = new TextView(this);
        label.setText(name);
        label.setTextSize(11);
        label.setTextColor(Color.parseColor("#E5E7EB"));
        label.setGravity(Gravity.CENTER);
        label.setMaxLines(2);
        label.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(6), 0, 0);
        item.addView(label, lp);

        item.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { openSite(sites.get(idx)[1]); }
        });
        item.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) {
                startDrag(idx, v);
                return true;
            }
        });
        item.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent e) {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) {
                    downRawX = e.getRawX();
                    downRawY = e.getRawY();
                    return false;
                }
                if (dragIdx != idx) return false;
                if (a == MotionEvent.ACTION_MOVE) {
                    moveDrag(e.getRawX(), e.getRawY());
                } else if (a == MotionEvent.ACTION_UP) {
                    endDrag(true);
                } else if (a == MotionEvent.ACTION_CANCEL) {
                    endDrag(false);
                }
                return true;
            }
        });

        loadFavicon(url, img, letter);
        return item;
    }

    private View makeAddItem() {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER_HORIZONTAL);
        item.setPadding(dp(2), dp(4), dp(2), dp(4));

        TextView plus = new TextView(this);
        plus.setText("+");
        plus.setTextSize(28);
        plus.setTextColor(Color.parseColor("#9CA3AF"));
        plus.setGravity(Gravity.CENTER);
        plus.setBackground(box("#111111", "#444444", 14));
        item.addView(plus, new LinearLayout.LayoutParams(iconSize, iconSize));

        TextView label = new TextView(this);
        label.setText("إضافة موقع");
        label.setTextSize(11);
        label.setTextColor(Color.parseColor("#9CA3AF"));
        label.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(6), 0, 0);
        item.addView(label, lp);

        item.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showEditDialog(-1); }
        });
        return item;
    }

    // ---------- سحب الأيقونة لتغيير الترتيب ----------

    private void startDrag(int idx, View v) {
        dragIdx = idx;
        targetIdx = idx;
        dragView = v;
        dragMoved = false;

        // حدود الصفوف (قبل ما نغيّر ترتيب الرسم)
        int n = grid.getChildCount();
        rowBottoms = new int[n];
        for (int i = 0; i < n; i++) {
            rowBottoms[i] = grid.getChildAt(i).getBottom() + dp(7);
        }

        // امنع الـ ScrollView من سرقة الحركة
        v.getParent().requestDisallowInterceptTouchEvent(true);

        // خلّي الأيقونة المسحوبة ترسم فوق الباقي
        ((View) v.getParent()).bringToFront();
        v.bringToFront();
        v.animate().scaleX(1.15f).scaleY(1.15f).alpha(0.85f).setDuration(120);
    }

    private void moveDrag(float rx, float ry) {
        if (dragView == null) return;
        float dx = rx - downRawX;
        float dy = ry - downRawY;
        if (Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8)) dragMoved = true;
        dragView.setTranslationX(dx);
        dragView.setTranslationY(dy);

        int t = targetFor(rx, ry);
        if (t != targetIdx) {
            if (targetIdx != dragIdx && targetIdx >= 0 && targetIdx < itemViews.size()) {
                itemViews.get(targetIdx).setAlpha(1f);
            }
            targetIdx = t;
            if (t != dragIdx && t >= 0 && t < itemViews.size()) {
                itemViews.get(t).setAlpha(0.35f);
            }
        }
    }

    // بيحسب المكان اللي إصبعك واقف فوقه دلوقتي
    private int targetFor(float rx, float ry) {
        int w = grid.getWidth();
        if (w <= 0 || sites.size() == 0) return dragIdx;
        int[] loc = new int[2];
        grid.getLocationOnScreen(loc);
        float relX = rx - loc[0];
        float relY = ry - loc[1];

        int vc = (int) (relX / (w / (float) COLS));
        if (vc < 0) vc = 0;
        if (vc > COLS - 1) vc = COLS - 1;
        int c = COLS - 1 - vc; // الشاشة RTL: العمود الأول على اليمين

        int r = rowBottoms.length - 1;
        for (int i = 0; i < rowBottoms.length; i++) {
            if (relY < rowBottoms[i]) { r = i; break; }
        }
        if (r < 0) r = 0;

        int t = r * COLS + c;
        if (t > sites.size() - 1) t = sites.size() - 1;
        if (t < 0) t = 0;
        return t;
    }

    private void endDrag(boolean up) {
        View v = dragView;
        int from = dragIdx;
        int to = targetIdx;
        boolean moved = dragMoved;
        dragIdx = -1;
        dragView = null;
        targetIdx = -1;
        for (int i = 0; i < itemViews.size(); i++) {
            itemViews.get(i).setAlpha(1f);
        }
        if (v == null) return;

        if (up && to != from && to >= 0 && to < sites.size()) {
            String[] s = sites.remove(from);
            sites.add(to, s);
            save();
            build();
            return;
        }

        v.animate().translationX(0).translationY(0)
            .scaleX(1f).scaleY(1f).alpha(1f).setDuration(150);

        // لو سبت الإصبع من غير ما تحرّك → قائمة التعديل والحذف
        if (up && !moved) {
            showOptions(from);
        }
    }

    // ---------- فتح الموقع في المتصفح الخارجي ----------

    private void openSite(String url) {
        Uri uri = Uri.parse(url);
        try {
            Intent i = Intent.makeMainSelectorActivity(
                Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER);
            i.setData(uri);
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
            } catch (Exception e2) {
                Toast.makeText(this, "مفيش متصفح يفتح الرابط ده", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // ---------- إضافة / تعديل / حذف ----------

    private void showOptions(final int idx) {
        String[] opts = { "تعديل", "حذف" };
        new AlertDialog.Builder(this)
            .setTitle(sites.get(idx)[0])
            .setItems(opts, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int which) {
                    if (which == 0) {
                        showEditDialog(idx);
                    } else {
                        confirmDelete(idx);
                    }
                }
            })
            .show();
    }

    private void confirmDelete(final int idx) {
        new AlertDialog.Builder(this)
            .setTitle("حذف الموقع")
            .setMessage("متأكد إنك عاوز تحذف \"" + sites.get(idx)[0] + "\"؟")
            .setPositiveButton("حذف", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int which) {
                    sites.remove(idx);
                    save();
                    build();
                }
            })
            .setNegativeButton("إلغاء", null)
            .show();
    }

    private void showEditDialog(final int idx) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(10), dp(20), 0);

        final EditText nameEt = new EditText(this);
        nameEt.setHint("اسم الموقع (اختياري)");
        nameEt.setSingleLine(true);
        box.addView(nameEt);

        final EditText urlEt = new EditText(this);
        urlEt.setHint("الرابط مثال: example.com");
        urlEt.setSingleLine(true);
        urlEt.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlEt.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        urlEt.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        box.addView(urlEt);

        if (idx >= 0) {
            nameEt.setText(sites.get(idx)[0]);
            urlEt.setText(sites.get(idx)[1]);
        }

        new AlertDialog.Builder(this)
            .setTitle(idx >= 0 ? "تعديل الموقع" : "إضافة موقع")
            .setView(box)
            .setPositiveButton("حفظ", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int which) {
                    String url = normalizeUrl(urlEt.getText().toString());
                    if (url == null) {
                        Toast.makeText(SitesActivity.this, "الرابط مش صحيح",
                            Toast.LENGTH_SHORT).show();
                        return;
                    }
                    String name = nameEt.getText().toString().trim();
                    if (name.length() == 0) {
                        name = hostOf(url);
                        if (name.startsWith("www.")) name = name.substring(4);
                    }
                    String[] entry = new String[] { name, url };
                    if (idx >= 0) {
                        sites.set(idx, entry);
                    } else {
                        sites.add(entry);
                    }
                    save();
                    build();
                }
            })
            .setNegativeButton("إلغاء", null)
            .show();
    }

    private String normalizeUrl(String t) {
        t = t.trim();
        if (t.length() == 0) return null;
        if (t.indexOf("://") < 0) t = "https://" + t;
        String host = hostOf(t);
        if (host == null || host.length() == 0 || host.indexOf('.') < 0) return null;
        return t;
    }

    private String hostOf(String url) {
        try {
            return Uri.parse(url).getHost();
        } catch (Exception e) {
            return null;
        }
    }

    // ---------- أيقونة الموقع (favicon) ----------

    private void loadFavicon(String url, final ImageView img, final TextView letter) {
        final String host = hostOf(url);
        if (host == null) return;
        final File f = new File(getFilesDir(), "fav_" + Math.abs(host.hashCode()) + ".png");

        if (f.exists()) {
            Bitmap b = BitmapFactory.decodeFile(f.getAbsolutePath());
            if (b != null) {
                img.setImageBitmap(b);
                img.setVisibility(View.VISIBLE);
                letter.setVisibility(View.GONE);
                return;
            }
        }

        new Thread(new Runnable() {
            public void run() {
                try {
                    URL u = new URL("https://www.google.com/s2/favicons?domain="
                        + host + "&sz=128");
                    HttpURLConnection c = (HttpURLConnection) u.openConnection();
                    c.setConnectTimeout(10000);
                    c.setReadTimeout(10000);
                    InputStream in = c.getInputStream();
                    FileOutputStream out = new FileOutputStream(f);
                    byte[] buf = new byte[4096];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        out.write(buf, 0, n);
                    }
                    out.close();
                    in.close();

                    final Bitmap b = BitmapFactory.decodeFile(f.getAbsolutePath());
                    if (b == null) {
                        f.delete();
                        return;
                    }
                    runOnUiThread(new Runnable() {
                        public void run() {
                            if (!alive) return;
                            img.setImageBitmap(b);
                            img.setVisibility(View.VISIBLE);
                            letter.setVisibility(View.GONE);
                        }
                    });
                } catch (Exception e) {
                    f.delete();
                }
            }
        }).start();
    }

    // ---------- أدوات ----------

    private String firstLetter(String s) {
        s = s.trim();
        if (s.length() == 0) return "؟";
        return s.substring(0, 1).toUpperCase();
    }

    private GradientDrawable box(String fill, String stroke, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.parseColor(fill));
        g.setCornerRadius(dp(radius));
        g.setStroke(dp(2), Color.parseColor(stroke));
        return g;
    }

    private LinearLayout.LayoutParams matchWrap(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
