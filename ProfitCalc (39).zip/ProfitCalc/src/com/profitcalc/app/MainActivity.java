package com.profitcalc.app;

import android.app.Activity;
import android.app.Dialog;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.MotionEvent;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final String PREFS = "profitcalc";
    private static final String KEY_RATE = "rate";
    private static final String DEFAULT_RATE = "55.80";

    private EditText input, rateInput;
    private TextView[] usd = new TextView[4];
    private TextView[] egp = new TextView[4];
    private SharedPreferences prefs;
    private TextView status;

    // خانة الحوشة (احوش كام عشان اجمع)
    private EditText goalInput, goalDaysInput;
    private Button goalCurBtn, goalUnitBtn;
    private boolean goalInUsd = true;
    private int goalUnit = 0; // 0 يوم، 1 أسبوع، 2 شهر
    private TextView[] gUsd = new TextView[3];
    private TextView[] gEgp = new TextView[3];
    private TextView goalNote;

    // الآلة الحاسبة
    private StringBuilder calcBuf = new StringBuilder();
    private TextView calcExprTv, calcResTv;
    private boolean justEvaluated = false;
    private String src;
    private int pos;
    private Dialog calcDlg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.parseColor("#000000"));
        scroll.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(10), dp(12), dp(80));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("حاسبة الأرباح");
        title.setTextSize(18);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(Color.parseColor("#FFFFFF"));
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap(0, 0, 0, 6));

        // صف فوق: سعر الدولار
        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER);

        // سعر الدولار: عنوان صغير + خانة + زرار تحديث صغير
        LinearLayout rateBox = new LinearLayout(this);
        rateBox.setOrientation(LinearLayout.VERTICAL);

        TextView rateLabel = new TextView(this);
        rateLabel.setText("سعر الدولار (ج.م)");
        rateLabel.setTextSize(11);
        rateLabel.setTextColor(Color.parseColor("#E5E7EB"));
        rateLabel.setGravity(Gravity.CENTER);
        rateBox.addView(rateLabel, matchWrap(0, 0, 0, 2));

        rateInput = makeInput("55.80", prefs.getString(KEY_RATE, DEFAULT_RATE));
        rateInput.setTextSize(15);
        rateInput.setPadding(dp(4), dp(4), dp(4), dp(4));

        Button refresh = new Button(this);
        refresh.setText("↻");
        refresh.setTextSize(16);
        refresh.setAllCaps(false);
        refresh.setTextColor(Color.WHITE);
        refresh.setMinHeight(0);
        refresh.setMinimumHeight(0);
        refresh.setMinWidth(0);
        refresh.setMinimumWidth(0);
        refresh.setPadding(0, 0, 0, 0);
        refresh.setBackground(box("#2563EB", "#2563EB"));
        refresh.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { fetchRate(); }
        });

        LinearLayout rateRow = new LinearLayout(this);
        rateRow.setOrientation(LinearLayout.HORIZONTAL);
        rateRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams lpInput = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lpInput.setMarginEnd(dp(4));
        rateRow.addView(rateInput, lpInput);
        rateRow.addView(refresh, new LinearLayout.LayoutParams(dp(32), dp(36)));
        rateBox.addView(rateRow, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        topRow.addView(rateBox, new LinearLayout.LayoutParams(
            dp(150), LinearLayout.LayoutParams.WRAP_CONTENT));

        root.addView(topRow, matchWrap(0, 0, 0, 6));

        TextView hint = new TextView(this);
        hint.setText("سعر الدولار بيتحدث تلقائيًا من النت، وتقدر تعدله بإيدك.");
        hint.setTextSize(11);
        hint.setTextColor(Color.parseColor("#9CA3AF"));
        root.addView(hint, matchWrap(0, 0, 0, 0));

        status = new TextView(this);
        status.setText("");
        status.setTextSize(11);
        status.setGravity(Gravity.CENTER);
        status.setTextColor(Color.parseColor("#9CA3AF"));
        root.addView(status, matchWrap(0, 0, 0, 6));

        // خانة الربح اليومي
        LinearLayout dailyRow = new LinearLayout(this);
        dailyRow.setOrientation(LinearLayout.HORIZONTAL);
        dailyRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        dailyRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView dailyLabel = makeLabel("كم تربح في اليوم؟ ($)");
        dailyLabel.setTextSize(14);
        dailyRow.addView(dailyLabel, new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        input = makeInput("مثال: 0.30", "");
        input.setTextSize(15);
        input.setPadding(dp(8), dp(4), dp(8), dp(4));
        dailyRow.addView(input, new LinearLayout.LayoutParams(dp(120),
            LinearLayout.LayoutParams.WRAP_CONTENT));
        root.addView(dailyRow, matchWrap(0, 0, 0, 8));

        String[] names = {"اليوم", "الأسبوع (7 أيام)", "الشهر (30 يوم)", "السنة (365 يوم)"};
        String[] colors = {"#60A5FA", "#34D399", "#FBBF24", "#F87171"};
        for (int i = 0; i < 4; i++) {
            addCard(root, i, names[i], colors[i]);
        }

        addGoalSection(root);

        TextWatcher watcher = new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable s) { calculate(); }
        };
        input.addTextChangedListener(watcher);
        rateInput.addTextChangedListener(watcher);
        goalInput.addTextChangedListener(watcher);
        goalDaysInput.addTextChangedListener(watcher);

        calculate();

        // زرار الآلة الحاسبة العايم
        FrameLayout frame = new FrameLayout(this);
        frame.addView(scroll, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        ImageView fab = new ImageView(this);
        fab.setImageResource(R.drawable.ic_calc);
        fab.setScaleType(ImageView.ScaleType.FIT_CENTER);
        fab.setPadding(dp(15), dp(15), dp(15), dp(15));
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Color.parseColor("#059669"));
        circle.setStroke(dp(2), Color.parseColor("#34D399"));
        fab.setBackground(circle);
        fab.setElevation(dp(8));
        fab.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { toggleCalculator(); }
        });
        FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(dp(60), dp(60));
        fp.gravity = Gravity.BOTTOM | Gravity.RIGHT;
        fp.setMargins(dp(16), dp(16), dp(16), dp(24));
        frame.addView(fab, fp);

        setContentView(BottomNav.wrap(this, frame, BottomNav.HOME));
        fetchRate();
    }

    private void calculate() {
        double daily = parse(input.getText().toString());
        double rate = parse(rateInput.getText().toString());

        prefs.edit().putString(KEY_RATE, rateInput.getText().toString()).apply();

        int[] days = {1, 7, 30, 365};
        for (int i = 0; i < 4; i++) {
            double d = daily * days[i];
            usd[i].setText(String.format(Locale.US, "%,.2f $", d));
            egp[i].setText(String.format(Locale.US, "%,.2f ج.م", d * rate));
        }
        calcGoal();
    }

    // ================= خانة: احوش كام عشان اجمع =================

    private void addGoalSection(LinearLayout parent) {
        String color = "#F472B6";
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(box("#1A1A1A", color));
        card.setPadding(dp(10), dp(8), dp(10), dp(8));

        TextView t = new TextView(this);
        t.setText("احوش كام عشان اجمع؟");
        t.setTextSize(15);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(Color.parseColor(color));
        card.addView(t, matchWrap(0, 0, 0, 6));

        // المبلغ + العملة (في صف واحد)
        goalInput = makeInput("1000", "");
        compactInput(goalInput);
        goalCurBtn = makeToggleBtn("$");
        goalCurBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                goalInUsd = !goalInUsd;
                goalCurBtn.setText(goalInUsd ? "$" : "ج.م");
                calcGoal();
            }
        });
        card.addView(inputRow("المبلغ اللي عاوز تجمعه", goalInput, goalCurBtn), matchWrap(0, 0, 0, 6));

        // المدة (في صف واحد)
        goalDaysInput = makeInput("3", "");
        compactInput(goalDaysInput);
        goalUnitBtn = makeToggleBtn("يوم");
        goalUnitBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                goalUnit = (goalUnit + 1) % 3;
                String[] u = {"يوم", "أسبوع", "شهر"};
                goalUnitBtn.setText(u[goalUnit]);
                calcGoal();
            }
        });
        card.addView(inputRow("في خلال كام؟", goalDaysInput, goalUnitBtn), matchWrap(0, 0, 0, 8));

        // النتائج (كل نتيجة في صف)
        String[] names = {"تحوش في اليوم", "تحوش في الأسبوع", "تحوش في الشهر"};
        for (int i = 0; i < 3; i++) {
            gUsd[i] = makeValueBox(color, "#0F2747");
            gEgp[i] = makeValueBox(color, "#0A2E22");
            compactBox(gUsd[i]);
            compactBox(gEgp[i]);
            card.addView(resultRow(names[i], gUsd[i], gEgp[i]), matchWrap(0, 0, 0, 5));
        }

        goalNote = new TextView(this);
        goalNote.setTextSize(12);
        goalNote.setTextColor(Color.parseColor("#FBBF24"));
        goalNote.setGravity(Gravity.CENTER);
        card.addView(goalNote, matchWrap(0, 0, 0, 0));

        parent.addView(card, matchWrap(0, 0, 0, 0));
    }

    private LinearLayout inputRow(String label, EditText et, Button btn) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView l = new TextView(this);
        l.setText(label);
        l.setTextSize(12);
        l.setTextColor(Color.parseColor("#9CA3AF"));
        row.addView(l, new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        LinearLayout.LayoutParams pe = new LinearLayout.LayoutParams(dp(100),
            LinearLayout.LayoutParams.WRAP_CONTENT);
        pe.setMarginEnd(dp(6));
        row.addView(et, pe);
        row.addView(btn, new LinearLayout.LayoutParams(dp(52), dp(34)));
        return row;
    }

    private LinearLayout resultRow(String name, TextView usdBox, TextView egpBox) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView n = new TextView(this);
        n.setText(name);
        n.setTextSize(12);
        n.setTextColor(Color.parseColor("#9CA3AF"));
        row.addView(n, new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 0.8f));
        LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1.1f);
        p1.setMargins(0, 0, dp(4), 0);
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1.1f);
        p2.setMargins(dp(4), 0, 0, 0);
        row.addView(usdBox, p1);
        row.addView(egpBox, p2);
        return row;
    }

    private void compactInput(EditText e) {
        e.setTextSize(14);
        e.setPadding(dp(6), dp(4), dp(6), dp(4));
    }

    // خانة قيمة صغيرة، والخط بيصغر لوحده لو الرقم طويل
    private void compactBox(TextView v) {
        v.setTextSize(13);
        v.setMaxLines(1);
        v.setPadding(dp(4), dp(6), dp(4), dp(6));
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            v.setAutoSizeTextTypeUniformWithConfiguration(8, 14, 1, TypedValue.COMPLEX_UNIT_SP);
        }
    }

    private Button makeToggleBtn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(0, 0, 0, 0);
        b.setBackground(box("#2563EB", "#2563EB"));
        return b;
    }

    private void calcGoal() {
        if (goalInput == null || goalDaysInput == null || gUsd[0] == null) return;
        double goal = parse(goalInput.getText().toString());
        double rate = parse(rateInput.getText().toString());
        double n = parse(goalDaysInput.getText().toString());
        int mult = goalUnit == 0 ? 1 : (goalUnit == 1 ? 7 : 30);
        double days = n * mult;

        double goalUsd = goalInUsd ? goal : (rate > 0 ? goal / rate : 0);
        double perDay = days > 0 ? goalUsd / days : 0;
        double[] per = {perDay, perDay * 7, perDay * 30};
        for (int i = 0; i < 3; i++) {
            gUsd[i].setText(String.format(Locale.US, "%,.2f $", per[i]));
            gEgp[i].setText(String.format(Locale.US, "%,.2f ج.م", per[i] * rate));
        }

        double daily = parse(input.getText().toString());
        if (goalUsd > 0 && daily > 0) {
            long d = (long) Math.ceil(goalUsd / daily);
            goalNote.setText("بربحك اليومي الحالي هتجمع المبلغ ده في " + d
                + " يوم (حوالي " + String.format(Locale.US, "%.1f", d / 30.0) + " شهر)");
        } else {
            goalNote.setText("");
        }
    }

    private void fetchRate() {
        status.setTextColor(Color.parseColor("#9CA3AF"));
        status.setText("جاري تحديث السعر من النت...");
        new Thread(new Runnable() {
            public void run() {
                String result = null;
                try {
                    URL url = new URL("https://open.er-api.com/v6/latest/USD");
                    HttpURLConnection c = (HttpURLConnection) url.openConnection();
                    c.setConnectTimeout(10000);
                    c.setReadTimeout(10000);
                    BufferedReader br = new BufferedReader(
                        new InputStreamReader(c.getInputStream(), "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) {
                        sb.append(line);
                    }
                    br.close();
                    JSONObject o = new JSONObject(sb.toString());
                    double r = o.getJSONObject("rates").getDouble("EGP");
                    if (r > 0) {
                        result = String.format(Locale.US, "%.2f", r);
                    }
                } catch (Exception e) {
                    result = null;
                }
                final String res = result;
                runOnUiThread(new Runnable() {
                    public void run() {
                        if (res != null) {
                            rateInput.setText(res);
                            status.setTextColor(Color.parseColor("#34D399"));
                            status.setText("تم تحديث السعر من النت ✔");
                        } else {
                            status.setTextColor(Color.parseColor("#F87171"));
                            status.setText("تعذر الاتصال بالنت، تم استخدام آخر سعر محفوظ");
                        }
                    }
                });
            }
        }).start();
    }

    private double parse(String t) {
        try {
            t = t.trim().replace(',', '.').replace('٫', '.');
            t = toEnglishDigits(t);
            if (t.length() > 0 && !t.equals(".")) {
                return Double.parseDouble(t);
            }
        } catch (Exception e) {
        }
        return 0;
    }

    private String toEnglishDigits(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '٠' && c <= '٩') {
                sb.append((char) ('0' + (c - '٠')));
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    private TextView makeLabel(String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextSize(16);
        label.setTextColor(Color.parseColor("#E5E7EB"));
        return label;
    }

    private EditText makeInput(String hintText, String value) {
        EditText e = new EditText(this);
        e.setHint(hintText);
        e.setText(value);
        e.setTextSize(16);
        e.setMinHeight(0);
        e.setMinimumHeight(0);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.parseColor("#6B7280"));
        e.setGravity(Gravity.CENTER);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setBackground(box("#1A1A1A", "#444444"));
        e.setPadding(dp(10), dp(6), dp(10), dp(6));
        return e;
    }

    private void addCard(LinearLayout parent, int index, String name, String color) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setBackground(box("#1A1A1A", color));
        card.setPadding(dp(10), dp(6), dp(10), dp(6));

        usd[index] = makeValueBox(color, "#0F2747");
        egp[index] = makeValueBox(color, "#0A2E22");
        compactBox(usd[index]);
        compactBox(egp[index]);

        card.addView(resultRow(name, usd[index], egp[index]));
        parent.addView(card, matchWrap(0, 0, 0, 6));
    }

    private TextView makeValueBox(String color, String bg) {
        TextView v = new TextView(this);
        v.setText("0.00");
        v.setTextSize(18);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setTextColor(Color.parseColor(color));
        v.setGravity(Gravity.CENTER);
        v.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        v.setPadding(dp(8), dp(12), dp(8), dp(12));
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.parseColor(bg));
        g.setCornerRadius(dp(10));
        v.setBackground(g);
        return v;
    }

    private GradientDrawable box(String fill, String stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.parseColor(fill));
        g.setCornerRadius(dp(12));
        g.setStroke(dp(2), Color.parseColor(stroke));
        return g;
    }

    private LinearLayout.LayoutParams matchWrap(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    // ================= الآلة الحاسبة (صغيرة على الجنب اليمين) =================

    private void toggleCalculator() {
        if (calcDlg != null && calcDlg.isShowing()) {
            calcDlg.dismiss();
        } else {
            showCalculator();
        }
    }

    private void showCalculator() {
        calcDlg = new Dialog(this);
        calcDlg.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        box.setBackground(boxR("#111111", "#333333", 14));
        box.setPadding(dp(8), dp(8), dp(8), dp(8));

        // شريط السحب: امسكه وحرّك الحاسبة في أي مكان
        TextView drag = new TextView(this);
        drag.setText("⠿  اسحب من هنا عشان تحرّكها  ⠿");
        drag.setTextSize(11);
        drag.setTextColor(Color.parseColor("#9CA3AF"));
        drag.setGravity(Gravity.CENTER);
        drag.setBackground(boxR("#1F2937", "#1F2937", 8));
        box.addView(drag, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(24)));

        calcExprTv = new TextView(this);
        calcExprTv.setTextSize(17);
        calcExprTv.setTextColor(Color.WHITE);
        calcExprTv.setGravity(Gravity.RIGHT);
        calcExprTv.setSingleLine(true);
        box.addView(calcExprTv, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        calcResTv = new TextView(this);
        calcResTv.setTextSize(20);
        calcResTv.setTypeface(Typeface.DEFAULT_BOLD);
        calcResTv.setTextColor(Color.parseColor("#34D399"));
        calcResTv.setGravity(Gravity.RIGHT);
        calcResTv.setSingleLine(true);
        calcResTv.setMinHeight(dp(30));
        box.addView(calcResTv, matchWrap(0, 0, 0, 6));

        String[][] rows = {
            {"C", "⌫", "÷", "×"},
            {"7", "8", "9", "−"},
            {"4", "5", "6", "+"},
            {"1", "2", "3", "."}
        };
        for (int r = 0; r < rows.length; r++) {
            LinearLayout line = new LinearLayout(this);
            line.setOrientation(LinearLayout.HORIZONTAL);
            for (int c = 0; c < 4; c++) {
                line.addView(makeKey(rows[r][c]), keyParams(1f));
            }
            box.addView(line, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(42)));
        }
        LinearLayout last = new LinearLayout(this);
        last.setOrientation(LinearLayout.HORIZONTAL);
        last.addView(makeKey("0"), keyParams(2f));
        last.addView(makeKey("="), keyParams(2f));
        box.addView(last, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(42)));

        Button send = new Button(this);
        send.setText("⬆ ودّي الناتج لليوم");
        send.setAllCaps(false);
        send.setTextSize(14);
        send.setTextColor(Color.WHITE);
        send.setPadding(0, 0, 0, 0);
        send.setMinHeight(0);
        send.setMinimumHeight(0);
        send.setBackground(boxR("#2563EB", "#2563EB", 10));
        send.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { confirmSendToToday(); }
        });
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(40));
        sp.setMargins(dp(2), dp(4), dp(2), dp(2));
        box.addView(send, sp);

        Button send2 = new Button(this);
        send2.setText("⬆ ودّي الناتج لـ كم تربح في اليوم");
        send2.setAllCaps(false);
        send2.setTextSize(12);
        send2.setTextColor(Color.WHITE);
        send2.setPadding(0, 0, 0, 0);
        send2.setMinHeight(0);
        send2.setMinimumHeight(0);
        send2.setBackground(boxR("#7C3AED", "#7C3AED", 10));
        send2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { confirmSendToInput(); }
        });
        LinearLayout.LayoutParams sp2 = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(40));
        sp2.setMargins(dp(2), dp(2), dp(2), dp(2));
        box.addView(send2, sp2);

        calcDlg.setContentView(box);
        Window w = calcDlg.getWindow();
        w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        // من غير تعتيم، ومن غير ما تسرق الفوكس، وتقدر تلمس الصفحة اللي ورا
        w.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        w.addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
            | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
        calcDlg.setCanceledOnTouchOutside(false);
        calcDlg.show();

        final int cw = dp(210);
        box.measure(View.MeasureSpec.makeMeasureSpec(cw, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        final int ch = box.getMeasuredHeight();
        final int sw = getResources().getDisplayMetrics().widthPixels;
        final int sh = getResources().getDisplayMetrics().heightPixels;

        final WindowManager.LayoutParams lp = w.getAttributes();
        lp.width = cw;
        lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        int sx = prefs.getInt("calc_x", -1);
        int sy = prefs.getInt("calc_y", -1);
        if (sx < 0 || sy < 0) {
            // أول مرة: تحت يمين الشاشة فوق زرار الحاسبة
            sx = sw - cw - dp(12);
            sy = sh - ch - dp(96) - dp(40) - dp(56);
        }
        lp.x = Math.max(0, Math.min(sx, sw - cw));
        lp.y = Math.max(0, Math.min(sy, sh - ch));
        w.setAttributes(lp);

        final Window fw = w;
        final float[] st = new float[4];
        drag.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent ev) {
                switch (ev.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        st[0] = ev.getRawX();
                        st[1] = ev.getRawY();
                        st[2] = lp.x;
                        st[3] = lp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = (int) Math.max(0, Math.min(st[2] + (ev.getRawX() - st[0]), sw - cw));
                        lp.y = (int) Math.max(0, Math.min(st[3] + (ev.getRawY() - st[1]), sh - ch));
                        fw.setAttributes(lp);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        prefs.edit().putInt("calc_x", lp.x).putInt("calc_y", lp.y).apply();
                        return true;
                }
                return false;
            }
        });

        updateCalcDisplay();
    }

    // بعت الناتج لخانة "كم تربح في اليوم" (بعد رسالة تأكيد)
    private void confirmSendToInput() {
        if (calcBuf.length() == 0) {
            Toast.makeText(this, "اكتب رقم الأول", Toast.LENGTH_SHORT).show();
            return;
        }
        double result;
        try {
            result = evalExpr(calcBuf.toString());
        } catch (Exception e) {
            Toast.makeText(this, "العملية مش مظبوطة", Toast.LENGTH_SHORT).show();
            return;
        }
        final String val = fmtNum(result);
        String old = input.getText().toString().trim();
        String msg = "تحط " + val + " $ في خانة (كم تربح في اليوم)؟";
        if (old.length() > 0) {
            msg += "\nالقيمة الحالية (" + old + ") هتتبدل.";
        }
        new AlertDialog.Builder(this)
            .setTitle("تأكيد")
            .setMessage(msg)
            .setPositiveButton("نعم", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int which) {
                    input.setText(val);
                    Toast.makeText(MainActivity.this, "تم ✔", Toast.LENGTH_SHORT).show();
                }
            })
            .setNegativeButton("لا", null)
            .show();
    }

    // بعت الناتج لخانة النهارده (بعد رسالة تأكيد)
    private void confirmSendToToday() {
        if (calcBuf.length() == 0) {
            Toast.makeText(this, "اكتب رقم الأول", Toast.LENGTH_SHORT).show();
            return;
        }
        double result;
        try {
            result = evalExpr(calcBuf.toString());
        } catch (Exception e) {
            Toast.makeText(this, "العملية مش مظبوطة", Toast.LENGTH_SHORT).show();
            return;
        }
        final String val = fmtNum(result);
        final String tk = TargetHelper.todayKey();
        String old = prefs.getString(tk, "");
        String msg = "تسجّل " + val + " $ كربح النهاردة؟";
        if (old.length() > 0) {
            msg += "\nالقيمة الحالية (" + old + ") هتتبدل.";
        }
        new AlertDialog.Builder(this)
            .setTitle("تأكيد")
            .setMessage(msg)
            .setPositiveButton("نعم", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int which) {
                    prefs.edit().putString(tk, val).apply();
                    Toast.makeText(MainActivity.this, "تم التسجيل ✔", Toast.LENGTH_SHORT).show();
                    TargetHelper.checkReached(MainActivity.this, prefs);
                }
            })
            .setNegativeButton("لا", null)
            .show();
    }

    @Override
    protected void onDestroy() {
        if (calcDlg != null && calcDlg.isShowing()) calcDlg.dismiss();
        super.onDestroy();
    }

    private LinearLayout.LayoutParams keyParams(float weight) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.MATCH_PARENT, weight);
        p.setMargins(dp(2), dp(2), dp(2), dp(2));
        return p;
    }

    private Button makeKey(final String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(17);
        b.setTextColor(Color.WHITE);
        b.setPadding(0, 0, 0, 0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        String bg = "#1F2937";
        if (label.equals("C")) bg = "#DC2626";
        else if (label.equals("⌫")) bg = "#4B5563";
        else if (label.equals("=")) bg = "#059669";
        else if (isOp(label.charAt(0))) bg = "#D97706";
        b.setBackground(boxR(bg, bg, 10));
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { onCalcKey(label); }
        });
        return b;
    }

    private boolean isOp(char c) {
        return c == '÷' || c == '×' || c == '−' || c == '+';
    }

    private void onCalcKey(String k) {
        char ch = k.charAt(0);
        if (k.equals("C")) {
            calcBuf.setLength(0);
            justEvaluated = false;
        } else if (k.equals("⌫")) {
            if (calcBuf.length() > 0) {
                calcBuf.deleteCharAt(calcBuf.length() - 1);
            }
            justEvaluated = false;
        } else if (k.equals("=")) {
            try {
                double v = evalExpr(calcBuf.toString());
                calcBuf.setLength(0);
                calcBuf.append(fmtNum(v));
                justEvaluated = true;
            } catch (Exception e) {
                if (calcBuf.length() > 0) {
                    calcExprTv.setText(calcBuf.toString());
                    calcResTv.setText("خطأ");
                    return;
                }
            }
        } else if (isOp(ch)) {
            justEvaluated = false;
            if (calcBuf.length() == 0) {
                if (ch == '−') calcBuf.append(ch);
            } else {
                char lastCh = calcBuf.charAt(calcBuf.length() - 1);
                if (isOp(lastCh)) {
                    if (calcBuf.length() > 1) {
                        calcBuf.setCharAt(calcBuf.length() - 1, ch);
                    }
                } else {
                    calcBuf.append(ch);
                }
            }
        } else if (k.equals(".")) {
            if (justEvaluated) { calcBuf.setLength(0); justEvaluated = false; }
            int start = 0;
            for (int i = calcBuf.length() - 1; i >= 0; i--) {
                if (isOp(calcBuf.charAt(i))) { start = i + 1; break; }
            }
            String seg = calcBuf.substring(start);
            if (seg.indexOf('.') < 0) {
                if (seg.length() == 0) calcBuf.append("0");
                calcBuf.append(".");
            }
        } else {
            if (justEvaluated) { calcBuf.setLength(0); justEvaluated = false; }
            if (calcBuf.length() < 40) {
                calcBuf.append(k);
            }
        }
        updateCalcDisplay();
    }

    private void updateCalcDisplay() {
        if (calcExprTv == null) return;
        calcExprTv.setText(calcBuf.length() == 0 ? "0" : calcBuf.toString());
        boolean hasOp = false;
        for (int i = 1; i < calcBuf.length(); i++) {
            if (isOp(calcBuf.charAt(i))) { hasOp = true; break; }
        }
        String res = "";
        if (hasOp) {
            try {
                res = "= " + fmtNum(evalExpr(calcBuf.toString()));
            } catch (Exception e) {
                res = "";
            }
        }
        calcResTv.setText(res);
    }

    private String fmtNum(double v) {
        if (v == Math.rint(v) && Math.abs(v) < 1e12) {
            return String.valueOf((long) v);
        }
        BigDecimal bd = new BigDecimal(v).setScale(8, RoundingMode.HALF_UP).stripTrailingZeros();
        return bd.toPlainString();
    }

    private double evalExpr(String s) {
        src = s.replace('÷', '/').replace('×', '*').replace('−', '-');
        pos = 0;
        double v = parseExpr();
        if (pos != src.length()) throw new RuntimeException("bad");
        return v;
    }

    private double parseExpr() {
        double v = parseTerm();
        while (pos < src.length()) {
            char c = src.charAt(pos);
            if (c == '+') { pos++; v += parseTerm(); }
            else if (c == '-') { pos++; v -= parseTerm(); }
            else break;
        }
        return v;
    }

    private double parseTerm() {
        double v = parseFactor();
        while (pos < src.length()) {
            char c = src.charAt(pos);
            if (c == '*') { pos++; v *= parseFactor(); }
            else if (c == '/') {
                pos++;
                double d = parseFactor();
                if (d == 0) throw new RuntimeException("div0");
                v /= d;
            } else break;
        }
        return v;
    }

    private double parseFactor() {
        if (pos < src.length() && src.charAt(pos) == '-') {
            pos++;
            return -parseFactor();
        }
        int start = pos;
        while (pos < src.length()
            && (Character.isDigit(src.charAt(pos)) || src.charAt(pos) == '.')) {
            pos++;
        }
        if (start == pos) throw new RuntimeException("num");
        return Double.parseDouble(src.substring(start, pos));
    }

    private GradientDrawable boxR(String fill, String stroke, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.parseColor(fill));
        g.setCornerRadius(dp(radius));
        g.setStroke(dp(2), Color.parseColor(stroke));
        return g;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
